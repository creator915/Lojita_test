Agda 2
======

[![Hackage version](https://img.shields.io/hackage/v/Agda.svg?label=Hackage)](http://hackage.haskell.org/package/Agda)
[![Stackage version](https://www.stackage.org/package/Agda/badge/lts?label=Stackage)](https://www.stackage.org/package/Agda)
[![Build, Test, and Benchmark](https://github.com/agda/agda/actions/workflows/test.yml/badge.svg)](https://github.com/agda/agda/actions/workflows/test.yml)
[![Documentation Status](https://readthedocs.org/projects/agda/badge/?version=latest)](http://agda.readthedocs.io/en/latest/?badge=latest)
[![Agda Zulip](https://img.shields.io/badge/zulip-join_chat-brightgreen.svg)](https://agda.zulipchat.com)

![The official Agda logo](https://raw.githubusercontent.com/agda/agda/master/doc/user-manual/agda.svg)

Note that this README is only about Agda, not its standard
library. See the [Agda Wiki][agdawiki] for information about the
library.

Documentation
-------------

* [User manual](http://agda.readthedocs.io)
  (per-commit pdf can be downloaded from the
  [github actions](https://github.com/agda/agda/actions/workflows/user_manual.yml) page)
* [CHANGELOG](https://github.com/agda/agda/blob/master/CHANGELOG.md)

Getting Started
----------------

* [Installation](https://agda.readthedocs.io/en/latest/getting-started/installation.html)
* [Quick guide to editing, type checking and compiling Agda
  code](https://agda.readthedocs.io/en/latest/getting-started/a-taste-of-agda.html)

Contributing to Agda
--------------------

* [Contributing to Agda](https://github.com/agda/agda/blob/master/CONTRIBUTING.md)
* [Haskell style-guide](https://github.com/andreasabel/haskell-style-guide/blob/master/haskell-style.md)

[agdawiki]: http://wiki.portal.chalmers.se/agda/pmwiki.php
